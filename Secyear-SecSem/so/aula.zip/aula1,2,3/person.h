#ifndef PERSON_H
#define PERSON_H

int new_person(char*name, int age);

int person_change_age(char* name, int age);

#endif

