package aula2ex1;

public class Main {
}
