package aula1ex1;

public class Increment implements Runnable {
    public void run() {
        final long I=100;

        for (long i = 0; i < I; i++)
            System.out.println("thread ["+ Thread.currentThread().getName()+"] " + i);
    }
}
