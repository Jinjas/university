from cmath import sqrt
import copy
import math 
import networkx as nx
import matplotlib.pyplot as plt
class Heuristica:
    def __init__(self, c1, c2):
        self.distancia_total = calcula_distancia_RR(c1, c2)
        self.estado_da_via_total = 1
        self.n = 1
        self.valor = self.distancia_total
        self.condicao = 1
        
    def atualizar_celula(self, distancia, estado_da_via):
        self.distancia_total += distancia
        self.estado_da_via_total += estado_da_via
        self.n += 1
        self.valor = self.distancia_total / self.n
        self.condicao = self.estado_da_via_total / self.n


#calcula a hipotenosa entre duas ruas
def calcula_distancia_RR(c1, c2):
        x1 = c1[0]
        y1 = c1[1]
        x2 = c2[0]
        y2 = c2[1]

        c1 = abs(x1-x2)

        c2 = abs(y1-y2)

        if c1 == 0:
            return c2
        if c2 == 0:
            return c1
        else: 
            return math.sqrt(c1*c1 + c2*c2)


#calcula a poupança de passar por outro nodo
def calcula_poupancas(distancia1, distancia2, distanciaPar):
    return ((distancia1 + distancia2)/2 - distanciaPar, distanciaPar)


def obter_pares(listaDeEncomendas, matriz, ox, oy):
    encomendaSimplificada = []
    poupancas = {}
    for encomenda in listaDeEncomendas:
        encomendaSimplificada.append(([(ox, oy) , (encomenda.delivery_address.x, encomenda.delivery_address.y)], encomenda))
        
    i = 1
    for elem in encomendaSimplificada:
        #elem2[0] = par de coordenadas
        #elem2[0][0] -> coordenadas origem
        #elem2[0][1] -> coordenadas destino
        #elem2[0][0][0] -> coordenada x origem
        #elem2[0][0][1] -> coordenada y origem
        #elem2[0][1][0] -> coordenada x destino
        #elem2[0][1][1] -> coordenada y destino
        for elem2 in encomendaSimplificada[i:]:
            (valor, distancia) = calcula_poupancas(matriz[elem[0][0][0]][elem[0][0][1]][elem[0][1][0]][elem[0][1][1]].valor, matriz[elem2[0][0][0]][elem2[0][0][1]][elem2[0][1][0]][elem2[0][1][1]].valor, matriz[elem[0][1][0]][elem[0][1][1]][elem2[0][1][0]][elem2[0][1][1]].valor) 
            poupancas[elem[1].id] = poupancas.get(elem[1].id,[elem[1],[]])
            poupancas[elem[1].id][1].append((elem2[1], valor,distancia, matriz[elem[0][1][0]][elem[0][1][1]][elem2[0][1][0]][elem2[0][1][1]].condicao))
            poupancas[elem2[1].id] = poupancas.get(elem2[1].id,[elem2[1],[]])
            poupancas[elem2[1].id][1].append((elem[1], valor,distancia, matriz[elem[0][1][0]][elem[0][1][1]][elem2[0][1][0]][elem2[0][1][1]].condicao))
        i += 1
    return poupancas

def obter_qualidades_do_veiculo(veiculoAtual):
    if veiculoAtual == 0:
      return 10, 5, 0.6, 0
    elif veiculoAtual == 1:
        return 35, 20, 0.5, 96
    else :
        return 50, 100, 0.1, 192


def trocar_para_veiculo_que_consiga(listaDeVeiculos, veiculoAtual, veiculoOriginal, peso, distancia_inicial, distancia_a_percorrer, prazo, listaOriginal, tempoInicial, condicao):
    if peso > 100 :
        return (False, veiculoOriginal,0, listaOriginal, 0)
    velocidade, capacidade, penalidade,poluicao = obter_qualidades_do_veiculo(veiculoAtual)
    aux = (distancia_inicial + distancia_a_percorrer)
    tempoFinal = tempoInicial + distancia_a_percorrer/((velocidade - capacidade * penalidade * 0.95) * condicao)
    if (peso <= capacidade) and (prazo >= tempoFinal):
            return (True, veiculoAtual,aux, listaDeVeiculos, poluicao * aux, tempoFinal)
    if veiculoAtual == 2:
        return (False, veiculoOriginal,aux, listaOriginal, poluicao * aux, tempoFinal)
    
    veiculoAtual += 1
    if listaDeVeiculos[veiculoAtual] > 0:
            listaDeVeiculos[veiculoAtual] -= 1
            listaDeVeiculos[veiculoAtual-1] += 1
    else :
        if veiculoAtual == 2:
            return (False, veiculoOriginal,aux, listaOriginal, poluicao * aux, tempoFinal)
        else:
            veiculoAtual += 1
            if listaDeVeiculos[veiculoAtual] > 0:
              listaDeVeiculos[veiculoAtual] -= 1
              listaDeVeiculos[veiculoAtual-1] += 1
            else:
             return (False, veiculoOriginal,aux, listaOriginal, poluicao * aux, tempoFinal)
    return trocar_para_veiculo_que_consiga(listaDeVeiculos, veiculoAtual, veiculoOriginal, peso, distancia_inicial, distancia_a_percorrer, prazo, listaOriginal, tempoInicial, condicao) 
        
def obter_proximo_veiculo(listaDeVeiculos):
    if listaDeVeiculos[0] > 0:
        listaDeVeiculos[0] -= 1
        return 0
    if listaDeVeiculos[1] > 0:
        listaDeVeiculos[1] -= 1
        return 1
    if listaDeVeiculos[2] > 0:
        listaDeVeiculos[2] -= 1
        return 2
    else:
        return -1



def calcula_rotas(encomendaAtual, poupancas, listaDeVeiculos, veiculoInicial, ox, oy, peso_atual, matriz, visitados, rota, poluicao_total, distancia_atual_esperada, encomendasDeFora, conjuntoDeRotas, tempo_esperado_total):
    numEncomendas = len(poupancas.keys())
    numVisitados = len(visitados)
    velocidade, capacidade, penalidade, poluicao_por_km = obter_qualidades_do_veiculo(veiculoInicial)
    conjuntoDeConjuntosDeRotas = []
    while True:
        while True:
            stored = False
            for caminho in poupancas[encomendaAtual][1][1]:
                if caminho[1] <= 0:
                        break
                #encomenda -> [0]
                #valor -> [1]
                #distancia -> [2]calcula_rotas
                if (caminho[0].id not in visitados) and (caminho[0].id not in encomendasDeFora):
                        peso = peso_atual + caminho[0].peso 
                        auxVelocidade = (velocidade - capacidade * penalidade * 0.95) * caminho[3]
                        auxTempo = tempo_esperado_total + caminho[2]/auxVelocidade
                        if peso < capacidade and (( auxTempo < caminho[0].prazo) or (calcula_distancia_RR((ox,oy), (caminho[0].delivery_address.x,caminho[0].delivery_address.y))/auxVelocidade > caminho[0].prazo )):
                                    stored = True
                                    peso_atual = peso
                                    distancia_atual_esperada = distancia_atual_esperada + caminho[2] 
                                    visitados.add(caminho[0].id)
                                    numVisitados += 1
                                    tempo_esperado_total = auxTempo
                                    encomendaAtual = caminho[0].id
                                    poluicao_total += poluicao_por_km * caminho[2]
                                    rota.append(caminho[0])
                                    break
                       
                        else :
                          (trocou, veiculo, distanciaTotal, novaListaDeVeiculos, novaPoluicao, novoTempoEsperado) = trocar_para_veiculo_que_consiga(copy.deepcopy(listaDeVeiculos), veiculoInicial, veiculoInicial, peso, distancia_atual_esperada, caminho[2], caminho[0].prazo, listaDeVeiculos, tempo_esperado_total, matriz[ox][oy][caminho[0].delivery_address.x][caminho[0].delivery_address.y].condicao)
                          if trocou :
                              aux_visitados = copy.deepcopy(visitados)
                              aux_visitados.add(caminho[0].id)
                              aux_rota = copy.deepcopy(rota)
                              aux_rota.append(caminho[0])
                              novaPoluicao = novaPoluicao - distancia_atual_esperada * poluicao_por_km 
                              novasRotas = calcula_rotas(caminho[0].id, poupancas, novaListaDeVeiculos, veiculo, ox, oy, peso, matriz, aux_visitados, aux_rota, novaPoluicao, distanciaTotal, copy.deepcopy(encomendasDeFora), copy.deepcopy(conjuntoDeRotas), novoTempoEsperado)
                              for rotaAux in novasRotas:
                                  conjuntoDeConjuntosDeRotas.append(rotaAux)
                          else:
                               encomendasDeFora.add(caminho[0].id)
                                
            if not stored:
                conjuntoDeRotas.append((rota, veiculoInicial, distancia_atual_esperada, peso_atual))      
                break
        if numVisitados == numEncomendas:
            break
        if len(encomendasDeFora) > 0:
            encomendasRestantes = list(encomendasDeFora)
            sorted(encomendasRestantes, key=lambda x : poupancas[x][0].prazo/matriz[ox][oy][poupancas[x][0].delivery_address.x][poupancas[x][0].delivery_address.y].valor)
            encomendaAtual = encomendasRestantes[0]
            encomendasDeFora = set()
        else :
            falhou = True
            for encomenda in poupancas.keys():
                if encomenda not in visitados:
                    encomendaAtual = encomenda
                    falhou = False
                    break
            if falhou:
                  break
        veiculoInicial = obter_proximo_veiculo(listaDeVeiculos)
        if veiculoInicial == -1:
            print("Sem Veiculos")
            break
        rota = [poupancas[encomendaAtual][0]]
        visitados.add(encomendaAtual)
        (trocou, veiculo, novaDistancia, novaListaDeVeiculos, novaPoluicao, novoTempoEsperado) = trocar_para_veiculo_que_consiga(copy.deepcopy(listaDeVeiculos), veiculoInicial, veiculoInicial, poupancas[encomendaAtual][0].peso, 0, matriz[ox][oy][poupancas[encomendaAtual][0].delivery_address.x][poupancas[encomendaAtual][0].delivery_address.y].valor, poupancas[encomendaAtual][0].prazo, listaDeVeiculos, 0, matriz[ox][oy][poupancas[encomendaAtual][0].delivery_address.x][poupancas[encomendaAtual][0].delivery_address.y].condicao)
        if trocou:
            listaDeVeiculos = novaListaDeVeiculos 
            poluicao_total += novaPoluicao
            veiculoInicial = veiculo
            tempo_esperado_total = novoTempoEsperado
            velocidade, capacidade, penalidade, poluicao_por_km = obter_qualidades_do_veiculo(veiculoInicial)
        else:
            poluicao_total = novaDistancia * poluicao_por_km   
            tempo_esperado_total = novaDistancia / ((velocidade  - penalidade * poupancas[encomendaAtual][0].peso) * matriz[ox][oy][poupancas[encomendaAtual][0].delivery_address.x][poupancas[encomendaAtual][0].delivery_address.y].condicao)

        distancia_atual_esperada = novaDistancia
        numVisitados +=1
        peso_atual = poupancas[encomendaAtual][0].peso

 
    conjuntoDeConjuntosDeRotas.append((conjuntoDeRotas, numVisitados, poluicao_total, len(conjuntoDeRotas)))
    return conjuntoDeConjuntosDeRotas
  
    #[[(tipodeveiculo, peso, [encomendas])]]
    
     
def calcula_prioridade(prazo, distancia, peso, veiculoInicial, listaDeVeiculos, condicao):
    if distancia == 0:
        return 0
    
    (_, veiculo, _, _,_,_) = trocar_para_veiculo_que_consiga(listaDeVeiculos, veiculoInicial, veiculoInicial, peso, 0, distancia, prazo, listaDeVeiculos, 0, condicao)
    velocidade, _, penalidade, _= obter_qualidades_do_veiculo(veiculo)
    return prazo/(distancia / (velocidade * peso * penalidade))
    
#lista de veículos é a lista que possui o número de veiculos de cada tipo por ordem crescente (bicicleta, mota, carro)
def get_rotas(listaDeEncomendas, listaDeVeiculos, matriz, ox, oy):
    poupancas = obter_pares(listaDeEncomendas, matriz, ox, oy)
    for i in poupancas.keys():
       poupancas[i][1] = (poupancas[i][1][0], sorted(poupancas[i][1], key=lambda x: x[1], reverse=True))
    veiculo = obter_proximo_veiculo(listaDeVeiculos)
    if veiculo == -1:
        return None
    listaDeEncomendas = sorted(listaDeEncomendas, key = lambda x: calcula_prioridade(x.prazo, matriz[0][0][x.delivery_address.x][x.delivery_address.y].valor, x.peso, veiculo, copy.deepcopy(listaDeVeiculos), matriz[0][0][x.delivery_address.x][x.delivery_address.y].condicao))
    visitados = set()
    visitados.add(listaDeEncomendas[0].id)
    (_, veiculo, distanciaTotal, novaListaDeVeiculos, poluicao,tempo) = trocar_para_veiculo_que_consiga(copy.deepcopy(listaDeVeiculos), veiculo, veiculo, listaDeEncomendas[0].peso, 0, matriz[0][0][listaDeEncomendas[0].delivery_address.x][listaDeEncomendas[0].delivery_address.y].valor, listaDeEncomendas[0].prazo, listaDeVeiculos, 0, matriz[0][0][listaDeEncomendas[0].delivery_address.x][listaDeEncomendas[0].delivery_address.y].condicao)
    return calcula_rotas(listaDeEncomendas[0].id, poupancas, novaListaDeVeiculos, veiculo, ox, oy, listaDeEncomendas[0].peso, matriz, visitados, [listaDeEncomendas[0]], poluicao, distanciaTotal, set(), [], tempo)

def calcula_velocidade_media_rota(conjuntoDeRotas, numvisitados):
    tempo_total =0
    for rota in conjuntoDeRotas:
        (_,velocidade,penalizacao, _) = obter_qualidades_do_veiculo(rota[1])
        tempo_total += rota[2] / (velocidade - rota[3]*penalizacao)
    return tempo_total/numvisitados

def calcula_melhor_conjunto_de_rotas(listaDeEncomendas, listaDeVeiculos, matriz, ox, oy):
    conjuntos_de_rotas = get_rotas(listaDeEncomendas, listaDeVeiculos, matriz, ox, oy)
    if conjuntos_de_rotas == None:
        return None
    conjuntos_de_rotas = sorted(conjuntos_de_rotas, key=lambda x:x[1], reverse=True)
    lenght = len(conjuntos_de_rotas)
    if lenght > 1:
        temp = conjuntos_de_rotas[0][1]
        for i in range(lenght):
         if conjuntos_de_rotas[i][1] != temp:
          conjuntos_de_rotas = conjuntos_de_rotas[:i]
          break
        lenght = len(conjuntos_de_rotas)

        if lenght > 1:
            conjuntos_de_rotas = sorted(conjuntos_de_rotas, key=lambda x:x[2])
            temp = conjuntos_de_rotas[0][2]
            for i in range(lenght):
              if conjuntos_de_rotas[i][2] != temp:
               conjuntos_de_rotas = conjuntos_de_rotas[:i]
               break
            lenght = len(conjuntos_de_rotas)
            if lenght > 1:
                conjuntos_de_rotas = sorted(conjuntos_de_rotas, key=lambda x:x[3])
                temp = conjuntos_de_rotas[0][3]
                for i in range(lenght):
                   if conjuntos_de_rotas[i][3] != temp:
                    conjuntos_de_rotas = conjuntos_de_rotas[:i]
                    break
                lenght = len(conjuntos_de_rotas)
                if lenght > 1:
                   conjuntos_de_rotas = sorted(conjuntos_de_rotas, key=lambda x:calcula_velocidade_media_rota(x[0], x[1]))
   
    return conjuntos_de_rotas[0]

def calcula_margem_de_erro(rota, matriz, ox, oy, velocidade, penalizaçao):
    tempo_atual = matriz[ox][oy][rota[0][0].delivery_address.x][rota[0][0].delivery_address.y].valor / ((velocidade - penalizaçao * rota[3]) * matriz[ox][oy][rota[0][0].delivery_address.x][rota[0][0].delivery_address.y].condicao)
    menor_erro = rota[0][0].prazo - tempo_atual
    peso_atual = rota[3] - rota[0][0].peso
    skip = True
    for encomenda in rota[0]:
        if skip: 
            skip = False 
        else :
            tempo_atual += matriz[ox][oy][encomenda.delivery_address.x][encomenda.delivery_address.y].valor /( (velocidade - penalizaçao * peso_atual) * matriz[ox][oy][encomenda.delivery_address.x][encomenda.delivery_address.y].condicao)
            if matriz[ox][oy][encomenda.delivery_address.x][encomenda.delivery_address.y].n < 20:
                incerteza = 3
            elif matriz[ox][oy][encomenda.delivery_address.x][encomenda.delivery_address.y].n < 50:
                incerteza = 2
            elif matriz[ox][oy][encomenda.delivery_address.x][encomenda.delivery_address.y].n < 100:
                incerteza = 1
            else :
                incerteza = 0
            margem_de_erro = encomenda.prazo - tempo_atual - incerteza
            if margem_de_erro < menor_erro:
                menor_erro = margem_de_erro
            peso_atual -= encomenda.peso
        ox = encomenda.delivery_address.x
        oy = encomenda.delivery_address.y

    return math.floor(menor_erro)
        

def atribuidor_de_urgencia(listaDeRotas, matriz, ox, oy, minCapacidade = 0.90):
    rotasQueValemAPena  =[]
    for rota in listaDeRotas:
        (velocidade,capacidade,penalização,_)  = obter_qualidades_do_veiculo(rota[1])
        if rota[3]/capacidade >= minCapacidade:
            rotasQueValemAPena.append([rota,0])
        else :
            rotasQueValemAPena.append([rota, calcula_margem_de_erro(rota, matriz, ox, oy, velocidade, penalização)])
    return rotasQueValemAPena
    
