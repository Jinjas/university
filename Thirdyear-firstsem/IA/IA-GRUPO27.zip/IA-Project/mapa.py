from cmath import sqrt
from graph import Grafo
from rua import Rua
from aresta import Aresta
import random
import math
from algoritmos import Heuristica
from meioTransporte import MeioTransporte
from encomenda import Encomenda
from algoritmos import calcula_melhor_conjunto_de_rotas, atribuidor_de_urgencia

tempoPorIteracao = 1/4
faturacao = 0.0

#recebe uma lista de pares que tem a encomenda onde a primeira é a encomenda e a segunda é o tempo
def atualizar_faturacao(resultados: list,transporte:MeioTransporte):
    global faturacao
    valorBase = 10
    pesoTotal = 0
    for (encomenda,tempo) in resultados:
        if encomenda.prazo >= tempo:
            transporte.avaliar(5)
        else:
            transporte.avaliar(max(1,5 - ((tempo-encomenda.prazo)/4)))
        valorBase += 30 / encomenda.prioridade + 5 * encomenda.volume
        pesoTotal += encomenda.peso
    faturacao += pesoTotal/transporte.capacidade * valorBase
    
    
def calcular_hipotenusa(rua1, rua2):
    return math.sqrt((rua2.x - rua1.x)**2 + (rua2.y - rua1.y)**2)

def atualizar_nodos_nao_visitados(nodo, nodos_nao_visitados, grafo):
    nodos_nao_visitados.remove(nodo)
    for vizinho in nodo.vizinhos:
        if vizinho in nodos_nao_visitados:
            nodos_nao_visitados = atualizar_nodos_nao_visitados(vizinho, nodos_nao_visitados, grafo)
    return nodos_nao_visitados

def completar_grafo(x, y, nodos_nao_visitados, grafo):
    if x < grafo.linhas and y < grafo.colunas:
        nodo = grafo.m_nodes[x][y]
        if nodo is not None:
            #print(f"Nodo atual: {nodo.nome}")
            nodos_nao_visitados.remove(nodo)
        while (len(nodos_nao_visitados) != 0):
            for vizinho in nodo.vizinhos:
                if vizinho in nodos_nao_visitados:
                    nodos_nao_visitados = atualizar_nodos_nao_visitados(vizinho, nodos_nao_visitados, grafo)
            if len(nodos_nao_visitados) == 0:
                return
            else:
                a = nodos_nao_visitados.pop()
                grafo.adicionar_aresta(nodo, a, Aresta(round(0.3 + calcular_hipotenusa(nodo, a), 2), round(random.triangular(0.5, 1.0, 0.75), 2)))
                nodo = a
            

def gerarRuas(n):
    ruas = []
    coordenadas_usadas = set()
    m = int(round(math.sqrt(n), 0))

    #Atribuir coordenadas às ruas
    for i in range(n):
        nome_rua = f"Rua{i}"
        rua = Rua(nome=nome_rua)
        rua.atualizar_coordenadas(i // m, i % m)
        ruas.append(rua)
        #print(f"{rua.nome} - Coordenadas: ({rua.x}, {rua.y})")

    return ruas

# generate graph from state
def gerarGrafo(ruas, n):
    tamanho = math.ceil(math.sqrt(n))
    grafo = Grafo(tamanho, tamanho)
    nodos_nao_visitados = set()

    for rua in ruas:
        grafo.add_nodo(rua)
    
    for rua in ruas:
        todas_arestas = [(rua, rua2) for rua2 in ruas if (rua != rua2 and (calcular_hipotenusa(rua, rua2) <= 5))]
        seleciona_aresta = random.sample(todas_arestas, k=random.randint(1,3))
        for (rua, rua2) in seleciona_aresta:	
            if len(rua.vizinhos) >= 3 or len(rua2.vizinhos) >= 3:
                break
            if rua2 in rua.vizinhos or rua in rua2.vizinhos:
                break
            distancia = round(0.3 + calcular_hipotenusa(rua, rua2), 2)
            rua.vizinhos.add(rua2)
            rua2.vizinhos.add(rua)
            condicao = round(random.triangular(0.5, 1.0, 0.75), 2)
            grafo.adicionar_aresta(rua, rua2, Aresta(distancia, condicao))
        nodos_nao_visitados.add(rua)

    #print arestas
    #for aresta in grafo.get_arestas_list(): print(aresta[0].nome, aresta[1].nome)

    completar_grafo(0, 0, nodos_nao_visitados, grafo)
    grafo.posicionar_armazem()
    grafo.atribuir_heuristicas()

    return grafo

def obter_matriz(grafo):
    matriz = [[[[None for _ in range(grafo.colunas)] for _ in range(grafo.linhas)] for _ in range(grafo.colunas)] for _ in range(grafo.linhas)]
    for i in range(len(grafo.m_nodes)):
        for j in range(len(grafo.m_nodes[0])):
                nodo_atual = grafo.m_nodes[i][j]
                if nodo_atual is not None:
                    matriz[nodo_atual.x][nodo_atual.y][0][0] = Heuristica((nodo_atual.x,nodo_atual.y), (0,0))
                    for h in range(len(grafo.m_nodes)):
                        for f in range(len(grafo.m_nodes[0])):
                            nodo = grafo.m_nodes[h][f]
                            if nodo is not None:
                                matriz[nodo_atual.x][nodo_atual.y][nodo.x][nodo.y] = Heuristica((nodo_atual.x,nodo_atual.y), (nodo.x,nodo.y))    
    return matriz

def imprimir_matriz(matriz):
    for x1 in range(len(matriz)):
        for y1 in range(len(matriz[0])):
            for x2 in range(len(matriz[0][0])):
                for y2 in range(len(matriz[0][0][0])):
                    if matriz[x1][y1][x2][y2] != None:
                        print(f"Elemento Matriz [{x1}][{y1}][{x2}][{y2}]: {matriz[x1][y1][x2][y2].valor if matriz[x1][y1][x2][y2] is not None else None}")


def parser(nome):
    dados = {}
    maior = 0
    with open(nome, 'r') as arquivo:
        for linha in arquivo:
            informacoes = linha.strip().split("|")
            if informacoes:
                instante = int(informacoes[0])
                if instante > maior:
                    maior = instante
                if instante not in dados:
                    dados[instante] = []
                
                dados[instante].append(informacoes[1:])
            else:
                print("Linha vazia ou sem informações.")
    return (dados, maior)

def atualizar_estado(grafo :Grafo, matriz :Heuristica, ox, oy, informacoes, encomendas:set, alterouInformacoesReferentesARotas, nodosAlterados:set, listaDeVeiculos):
    for informacao in informacoes:
                if informacao and informacao[0] == "E":
                    id_encomenda = Encomenda.chave_atual
                    Encomenda.chave_atual += 1
                    endereco = grafo.get_nodo_by_name(informacao[3])
                    prazo = matriz[ox][oy][endereco.x][endereco.y].valor * int(informacao[4]) * 2
                    id_cliente = informacao[2]
                    encomendas.add(Encomenda(id_encomenda, int(informacao[1]), -1, prazo, int(informacao[5]), id_cliente, endereco, int(informacao[4])))
                    print("Nova Encomenda -> id ", id_encomenda, "peso ", int(informacao[1]), "prazo ", prazo, "id_cliente ", id_cliente, "endereço de entrega ", endereco)
                    alterouInformacoesReferentesARotas[0] = True
                elif informacao and informacao[0] == "A":
                    rua1 = grafo.get_nodo_by_name(informacao[1])
                    rua2 = grafo.get_nodo_by_name(informacao[2])
                    nodosAlterados.add(rua1)
                    nodosAlterados.add(rua2)
                    grafo.atualizar_condicao(rua1, rua2, informacao[3])
                    if float(informacao[3]) < 0.01:
                        print("Cortamos a rua de ", rua1, "para a ", rua2)
                    elif float(informacao[3]) > 0.01:
                        print("Alteramos a condição de ", rua1, "para a ", rua2)
                elif informacao and informacao[0] == "V":
                    print("Adicionamos uma novo veículo do tipo ", informacao[1])
                    listaDeVeiculos[int(informacao[1])].add(MeioTransporte(int(informacao[1]), ox, oy))
                    alterouInformacoesReferentesARotas[0] = True
    print(" ")


    
def gestor_de_eventos(grafo, matriz, ox, oy, nomeDoFicheiro):    
    (dados,limite) = parser(nomeDoFicheiro)
    indice = 0
    encomendas = set()
    VeiculosDisponiveis = [set(), set(), set()]
    VeiculosEmMovimento = set()
    conjuntoDeRotas = []
    alterouInformacoesRelevantes = []
    alterouInformacoesRelevantes.append(False)
    nodosAlterados = set()
    while (len(encomendas) > 0) or (indice <= limite) or (len(VeiculosEmMovimento)>0):
        print("Instante ", indice)
        if indice in dados:
           informacoes = dados[indice]
           atualizar_estado(grafo, matriz, ox, oy, informacoes, encomendas, alterouInformacoesRelevantes, nodosAlterados, VeiculosDisponiveis)
                    
        ####É AQUI QUE TEMOS DE POR O CÓDIGO PARA REALIZAR AS PESQUISAS
        
        #selecionar rotas
        if alterouInformacoesRelevantes[0] and len(encomendas) > 0:
            conjuntoDeRotas = calcula_melhor_conjunto_de_rotas(list(encomendas), [len(VeiculosDisponiveis[0]),len(VeiculosDisponiveis[1]),len(VeiculosDisponiveis[2])], matriz, 0 ,0)
            conjuntoDeRotas = atribuidor_de_urgencia(conjuntoDeRotas[0], matriz, ox, oy)
            alterouInformacoesRelevantes[0] = False
            
        length = len(conjuntoDeRotas)
        i=0
        rotasSelecionadas = []
        
        #preparar veiculos para andar
        while(i < length):
            if conjuntoDeRotas[i][1] <=0:
                rotasSelecionadas.append(i)
                print("Rota que entrou ", conjuntoDeRotas[i][0])
                veiculoAtual = VeiculosDisponiveis[conjuntoDeRotas[i][0][1]].pop()
                veiculoAtual.inicializar_deslocacao(conjuntoDeRotas[i][0])
                VeiculosEmMovimento.add(veiculoAtual)
            i += 1
        
            
        ids_encomendas_selecionadas = []
        for valor in rotasSelecionadas:
            for encomenda in conjuntoDeRotas[valor][0][0]:
                ids_encomendas_selecionadas.append(encomenda.id)
            conjuntoDeRotas.pop(valor)
        encomendas = {x for x in encomendas if x.id not in ids_encomendas_selecionadas}
        
        print("Encomenda selecionadas", encomendas)
        print("Veiculos em Movimento ", VeiculosEmMovimento)
        veiculosARemover = []
        for veiculo in VeiculosEmMovimento:
           resultado = veiculo.move(tempoPorIteracao * indice, tempoPorIteracao, grafo, matriz, nodosAlterados)
           print("Resultado ", resultado)
           #utilizar a lista em resultado[0] para processar faturação e fazer avaliações
           atualizar_faturacao(resultado[0],veiculo)
           print("faturacao",faturacao)

           if veiculo.num_classificações is not 0:
            print ("avaliação do veiculo: ",veiculo.get_classificacao())

           if resultado[1]:
            veiculosARemover.append(veiculo)
        
        for veiculo in veiculosARemover:
               VeiculosDisponiveis[veiculo.tipo_transporte].add(veiculo)
               VeiculosEmMovimento.remove(veiculo)
               
        length = len(conjuntoDeRotas)
        i=0
        while(i < length):
            conjuntoDeRotas[i][1] -= 1
            i += 1
            
        
        nodosAlterados = set()
        
        entrada = input("Pressione Enter para passar para o próximo instante.")
        print(" ")
        #PARA NÃO SER CHATO DE TESTAR    
        if not entrada:
            indice+=1
            print("-------------------Passou para o próximo instante-------------------")
            print(" ")
        else:
                print("!!!!!!!!!!!!!!!!!!!Você não pressionou Enter. Tente novamente!!!!!!!!!!!!!!!!!!!")
                print(" ")
            
                        
                        
                
                                   
                
        
