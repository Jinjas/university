class Rua:
    def __init__(self, nome, distancia = 0, x = 0, y = 0):
        self.nome = nome
        self.distancia = distancia
        self.x = x
        self.y = y
        self.vizinhos = set()

    def __str__(self):
        return self.nome 

    def atualizar_coordenadas(self, x, y):
        self.x = x
        self.y = y

    def atualizar_nome(self, nome):
        self.nome = nome

    def get_X(self):
        return self.x
    
    def get_Y(self):
        return self.y
    
    def get_Nome(self):
        return self.nome
    