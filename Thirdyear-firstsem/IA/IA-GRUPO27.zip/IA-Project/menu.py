from cliente import Client
import sys
 
class Menu:

    def __init__(self, healthPlanet):
        self.healthPlanet = healthPlanet

    def registo(self):
        print("Processo de registo:")
        name = input("Enter your name: ")
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        address = input("Enter your address: ")

        client = client(name, username, password, address)

        self.healthPlanet.addclient(client)

        print("Registo completo!")

    def login(self):
        print("Processo de login:")
        username = input("Enter your username: ")
        password = input("Enter your password: ")

        autenticacao = self.healthPlanet.verificarclient(username,password)

        if autenticacao:
            self.menu_client()

    def exit(self):
        print("Exiting the program!")
        sys.exit()


    def menu_client(self):
        choices = {
            "2" : self.exit
        }
        while True:
            print("Delivery System Menu:")
            print("1. Realizar encomenda")
            print("2. Sair")
            escolha = input("Enter your choice: ")
            if escolha in choices:
                choices[escolha]()

    def main_menu(self):
        choices = {
            "1" : self.registo,
            "2" : self.login,
            "3" : self.exit
        }
        while True:
            print("Delivery System Menu:")
            print("1. Registo")
            print("2. Login")
            print("3. Sair")
            escolha = input("Enter your choice: ")
            if escolha in choices:
                choices[escolha]()
    