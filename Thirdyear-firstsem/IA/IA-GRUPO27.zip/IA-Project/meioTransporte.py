from algoritmos import Heuristica, obter_qualidades_do_veiculo
from encomenda import Encomenda
from graph import Grafo

        
def atualizar_heuristicas(matriz, caminho_percorrido):
        i = 0
        lenght = len(caminho_percorrido)
        while i < lenght:
            j = i
            distancia_total = 0
            condicao_total = 0
            n = 0
            while j < lenght:
                distancia_total += caminho_percorrido[j][1]
                condicao_total += caminho_percorrido[j][2]
                n +=1 
                condicao_media = condicao_total / n
                matriz[caminho_percorrido[i][0][0]][caminho_percorrido[i][0][1]][caminho_percorrido[j][0][2]][caminho_percorrido[j][0][3]].atualizar_celula(distancia_total, condicao_media)
                matriz[caminho_percorrido[j][0][2]] [caminho_percorrido[j][0][3]][caminho_percorrido[i][0][0]][caminho_percorrido[i][0][1]].atualizar_celula(distancia_total, condicao_media)
                j+=1
            i += 1

class MeioTransporte:
    chave_atual = 0

    def __init__(self, tipo_transporte, x, y):
        self.id = MeioTransporte.chave_atual
        MeioTransporte.chave_atual += 1
        self.classificacao_total = 0
        self.num_classificações = 0
        self.tipo_transporte = tipo_transporte
        self.distancia = 0
        self.velocidade_max, self.capacidade, self.penalidade, self.poluicao_por_km = obter_qualidades_do_veiculo(tipo_transporte)
        self.coordenadas_armazem = [x,y]
        self.coordenadas_atuais = [x,y]
        self.lista_de_encomendas = []
        self.percurso = []
        self.caminho_percorrido = []
        self.rota = []
        
    def avaliar(self, classificacao):
        self.num_classificações += 1
        self.classificacao_total += classificacao
        
    def get_classificacao(self):
        return round(self.classificacao_total / self.num_classificações, 2)
        
    def inicializar_deslocacao(self, rota):
        self.lista_de_encomendas = rota[0]
        self.peso  = rota[3]
        self.distancia = 0
        self.visitados = set()
    
    #Retorna um par. O primeiro elemento desse par é uma lista onde cada elemento é um par, onde o primeiro é a encomenda que foi entregue e o segundo é o instante de tempo. O segundo elemento do par é um bool que diz se o veiculo regressou ao armazem ou não
    def move(self, tempo_inical, intervalo_de_tempo_original, grafo:Grafo, matriz:Heuristica, listaDeAlterados):
        intervalo_de_tempo = intervalo_de_tempo_original
        if (len(self.visitados) == 0) or any(element in self.visitados for element in listaDeAlterados):
            self.percurso, self.visitados = grafo.procura_aStar(grafo.get_nodo_by_coordendas(self.coordenadas_atuais[0], self.coordenadas_atuais[1]), grafo.get_nodo_by_coordendas(self.lista_de_encomendas[0].delivery_address.x, self.lista_de_encomendas[0].delivery_address.y), matriz)

            self.visitados = set(self.visitados)
        encomendasRealizadas = []
        calcularP = False
        lenghtEncomendas = (len(self.lista_de_encomendas))
        while (intervalo_de_tempo > 0) and lenghtEncomendas > 0:
            i = 0
            if calcularP:
                self.percurso, self.visitados = grafo.procura_aStar(grafo.get_nodo_by_coordendas(self.coordenadas_atuais[0], self.coordenadas_atuais[1]), grafo.get_nodo_by_coordendas(self.lista_de_encomendas[0].delivery_address.x, self.lista_de_encomendas[0].delivery_address.y), matriz)
                self.visitados = set(self.visitados)
            while(i < len(self.percurso) - 1):
                distancia, condicao = grafo.get_aresta(self.percurso[0], self.percurso[1])
                tempoGasto = (distancia - self.distancia)/((self.velocidade_max - self.peso * self.penalidade) * condicao)
                if tempoGasto > intervalo_de_tempo:
                    self.distancia = distancia - (tempoGasto - intervalo_de_tempo) * ((self.velocidade_max - self.peso * self.penalidade) * condicao)
                    self.coordenadas_atuais = [self.percurso[0].x, self.percurso[0].y]
                    return (encomendasRealizadas, False)
                else :
                    intervalo_de_tempo -= tempoGasto
                    self.caminho_percorrido.append([(self.percurso[0].x, self.percurso[0].y,self.percurso[1].x, self.percurso[1].y), distancia, condicao])
                    self.percurso = self.percurso[1:]
                    self.distancia = 0
            calcularP = True 
            atualizar_heuristicas(matriz, self.caminho_percorrido)
            self.caminho_percorrido  = []
            self.peso -= self.lista_de_encomendas[0].peso
            self.coordenadas_atuais = [self.lista_de_encomendas[0].delivery_address.x, self.lista_de_encomendas[0].delivery_address.y]
            encomendasRealizadas.append((self.lista_de_encomendas.pop(0), tempo_inical + intervalo_de_tempo_original - intervalo_de_tempo))
            lenghtEncomendas -=1
        
        while (intervalo_de_tempo > 0):
            if self.distancia == 0:
                self.percurso, self.visitados = grafo.procura_aStar(grafo.get_nodo_by_coordendas(self.coordenadas_atuais[0], self.coordenadas_atuais[1]), grafo.get_nodo_by_coordendas(self.coordenadas_armazem[0], self.coordenadas_armazem[1]), matriz)
                self.visitados = set(self.visitados)
            lenght = len(self.percurso) - 1
            if lenght < 0 :
                break
            while(len(self.percurso) - 1 > 0):
                distancia, condicao = grafo.get_aresta(self.percurso[0], self.percurso[1])
                tempoGasto = (distancia - self.distancia)/((self.velocidade_max - self.peso * self.penalidade) * condicao)
                if tempoGasto > intervalo_de_tempo:
                    self.distancia = distancia - (tempoGasto - intervalo_de_tempo) * ((self.velocidade_max - self.peso * self.penalidade) * condicao)
                    self.coordenadas_atuais = [self.percurso[0].x, self.percurso[0].y]
                    return (encomendasRealizadas, False)
                else :
                    intervalo_de_tempo -= tempoGasto
                    self.caminho_percorrido.append([(self.percurso[0].x, self.percurso[0].y,self.percurso[1].x, self.percurso[1].y), distancia, condicao])
                    self.percurso = self.percurso[1:]
                    self.distancia = 0
            atualizar_heuristicas(matriz, self.caminho_percorrido)
            self.coordenadas_atuais = [self.percurso[len(self.percurso)-1].x, self.percurso[len(self.percurso)-1].y]
            self.caminho_percorrido  = []
   
            
        return (encomendasRealizadas, True)
        