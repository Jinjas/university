# IA-Project
## Problem Solving using Search Algorithms project from Artificial Intelegence subject

Rodrigo Viana Ramos Casal Novo (A100534),
José Afonso Lopes Correia (A100610),
Mariana Antunes Silva (A100702),
João Paulo Campelo Gomes (A100747)
