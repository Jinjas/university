class Estafeta:
    def __init__(self, name, id, classification, transport):
        self.name = name
        self.id = id
        self.classification = classification
        self.transport = transport

    def get_name(self):
        return self.name

    def get_id(self):
        return self.id

    def get_classification(self):
        return self.classification

    def get_transport(self):
        return self.transport
    
