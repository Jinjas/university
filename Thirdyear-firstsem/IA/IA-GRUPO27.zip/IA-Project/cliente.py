class Cliente:
    def __init__(self, id, name, address):
        self.id = id
        self.name = name
        self.address = address

