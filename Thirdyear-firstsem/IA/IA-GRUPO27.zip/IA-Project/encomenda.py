import datetime

class Encomenda:
    chave_atual = 0
    def __init__(self, id, peso, tipo_transporte, prazo, volume, client_id, delivery_address, prioridade):
        self.id = id
        self.peso = peso
        self.tipo_transporte = tipo_transporte
        self.prazo = prazo
        self.volume = volume
        self.client_id = client_id
        self.delivery_address = delivery_address
        self.prioridade = prioridade

    
    def getId(self):
        return id
    
    def getPeso(self):
        return self.aresta

    def gettipoTransporte(self):
        return self.tipo_transporte

    def getTime(self):
        return self.time

    def getVolume(self):
        return self.volume

    def getclient(self):
        return self.client_id

    def getDeliveryAddress(self):
        return self.delivery_address
    
