from cmath import sqrt
import math
import networkx as nx
import matplotlib.pyplot as plt
from algoritmos import Heuristica
from rua import Rua
from aresta import Aresta
from queue import Queue

class Grafo:
            
    def __init__ (self, linhas, colunas, direcao = False):
        self.linhas = linhas
        self.colunas = colunas
        self.m_nodes = [[None for _ in range(colunas)] for _ in range(linhas)] # matriz de nodos
        self.m_derecao = direcao # se é dirigido ou não
        self.m_grafo = {} # dicionário de arestas
        self.m_h = {} # dicionário de heurísticas

    def __str__(self):
        out = ""
        for key in self.m_grafo.keys():
            out = out + "node" + str(key) + ":" + str(self.m_grafo[key]) + "\n"
        return out
        
    def add_nodo(self, nodo):
        if 0 <= nodo.x < self.linhas and 0 <= nodo.y < self.colunas:
            self.m_nodes[nodo.x][nodo.y] = nodo
            self.m_grafo[nodo] = set()

    #armazem no centro do grafo
    def posicionar_armazem(self):
        x = self.linhas//2
        y = self.colunas//2
        self.m_nodes[x][y].atualizar_nome("Armazem")


    def get_nodo_by_coordendas(self, x, y):
        return self.m_nodes[x][y] if self.m_nodes[x][y] else None  # Return None after checking all nodos in list

    def get_nodo_by_name(self, nome):
        for i in range(self.linhas):
            for j in range(self.colunas):
                elemento = self.m_nodes[i][j]
                if (elemento != None) and (elemento.nome == nome):
                     return self.m_nodes[i][j] if self.m_nodes[i][j] else None

    def verficarNodo(self, nodo):
        for i in range(self.linhas):
            for j in range(self.colunas):
                if self.m_nodes[i][j] == nodo:
                    return True
        return False


    def adicionar_aresta (self, rua1, rua2, aresta):
        if (self.verficarNodo(rua1) == False):
            self.add_nodo(rua1)
        else: rua1 = self.get_nodo_by_coordendas(rua1.x, rua1.y)

        if (self.verficarNodo(rua2) == False):
            self.add_nodo(rua2)
        else: rua2 = self.get_nodo_by_coordendas(rua2.x, rua2.y)

        self.m_grafo[rua1].add((rua2, aresta))
        
        if not self.m_derecao:
            self.m_grafo[rua2].add((rua1, aresta))

    def atualizar_condicao(self, rua1, rua2, condicao):
        a = self.m_grafo[rua1]
        for (nodo,custo) in a:
            if nodo == rua2:
                custo.condicao = condicao
                break

    def get_Nodos (self):
        return self.m_nodes


    def get_aresta_cost(self, rua1, rua2):
        custoT = math.inf
        a = self.m_grafo[rua1]
        for (nodo, aresta) in a:
            if nodo == rua2:
                custoT = aresta.distancia/aresta.condicao
        return custoT

    
    def get_aresta(self, rua1, rua2):
        if rua1 == rua2:
            return 0, 1
        a = self.m_grafo[rua1]
        for (nodo, aresta) in a:
            if nodo == rua2:
                return (aresta.distancia, aresta.condicao)

    def get_arestas_list(self):
        arestas = []
        for nodo in self.m_grafo:
            for aresta in self.m_grafo[nodo]:
                arestas.append((nodo, aresta[0], aresta[1]))
        return arestas


    def get_vizinhos(self, nodo):
        lista = []
        for (adjacente, peso) in self.m_grafo[nodo]:
            lista.append((adjacente, peso))
        return lista

    #Desenhar grafo
    def draw(self):
        G = nx.DiGraph()
        all_nodes = [node for row in self.m_nodes for node in row if node]
        G.add_nodes_from(all_nodes)
        G.add_weighted_edges_from(self.get_arestas_list())

        #pos = nx.spring_layout(G)
        pos = nx.random_layout(G)
        

        nx.draw(G, pos, with_labels=True, node_size=700, node_color="skyblue", font_size=10, font_color="black", arrows=False)

        # Adicionar informações da rua ao lado das arestas
        edge_labels = {(edge[0], edge[1]): f"{edge[2]['weight'].distancia}km, {edge[2]['weight'].condicao}%" for edge in G.edges(data=True)}
        nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=8, font_color="purple")

        plt.show()

    def calcula_distancia_RR(self, rua1, rua2):
        x1 = rua1.get_X()
        y1 = rua1.get_Y()
        x2 = rua2.get_X()
        y2 = rua2.get_Y()

        c1 = abs(x1-x2)

        c2 = abs(y1-y2)

        if c1 == 0:
            return c2
        if c2 == 0:
            return c1
        else: 
            return sqrt(c1*c1 + c2*c2)

    #função que escolhe das estimativas, o nodo que tem a menor
    def calcula_est(self, estima):
        l = list(estima.keys())
        min_estima = estima[l[0]]
        node = l[0]
        for k, v in estima.items():
            if v < min_estima:
                min_estima = v
                node = k
        return node
    
    #função que devolve um dicionário com os nodos 
    def getNodeDict(self):
        result = {}
        i = -1
        j = -1
        for line in self.m_nodes:
            i +=1
            for column in line:
                j +=1
                result[(i,j)] = column
        return result
    

    #arranjar heuristica de um nodo
    def getH(self, nodo, objetivo):
        if nodo not in self.m_h.keys():
            return 1000
        else:
            self.m_h[nodo] = self.calcula_distancia_RR(nodo, objetivo)
            return (self.m_h[nodo])


    #atribuir heuristica a todos os nodos
    def atribuir_heuristicas(self):
        nodos = self.getNodeDict()
        for (x, y) in nodos.keys():
            self.m_h[(x,y)] = 1 
        return (True)
    
    
#A estrela genérico
#start -> nodo inicial(armazem)
#end -> nodo destino
    def procura_aStar(self, start, end, matriz:Heuristica):
        if start == end :
         return ([], [])
        # open_list is a list of nodes which have been visited, but who's neighbors
        # haven't all been inspected, starts off with the start node
        # closed_list is a list of nodes which have been visited
        # and who's neighbors have been 
        open_list = {start}
        closed_list = set([])

        # g contains current distances from start_node to all other nodes
        # the default value (if it's not found in the map) is +infinity
        g = {}  ##  g é para substiruir pelo peso

        g[start] = 0

        # parents contains an adjacency map of all nodes
        parents = {}
        parents[start] = start
        n = None
        while len(open_list) > 0:
            # find a node with the lowest value of f() - evaluation function
            calc_heurist = {}
            flag = 0
            for v in open_list:
                if n == None:
                    n = v
                else:
                    flag = 1
                    calc_heurist[v] = g[v] + matriz[v.x][v.y][end.x][end.y].valor
            if flag == 1:
                min_estima = self.calcula_est(calc_heurist)
                n = min_estima
            if n == None:
                print('Path does not exist!')
                return None

            # if the current node is the stop_node
            # then we begin reconstructin the path from it to the start_node
            #print(n, end)
            if n.nome == end.nome:

                reconst_path = []

                condicaoTotal = 0
                while parents[n] != n:
                    reconst_path.append(n)
                    n = parents[n]

                reconst_path.append(start)
                reconst_path.reverse()

                #print('Path found: {}'.format(reconst_path))
                return (reconst_path, closed_list)

            # for all neighbors of the current node do
            for (m, aresta) in self.get_vizinhos(n):  # definir função get_vizinhos  tem de ter um par nodo peso
                # if the current node isn't in both open_list and closed_list
                # add it to open_list and note n as it's parent
                if m not in open_list and m not in closed_list:
                    open_list.add(m)
                    parents[m] = n
                    g[m] = g[n] + (aresta.distancia/aresta.condicao)

                # otherwise, check if it's quicker to first visit n, then m
                # and if it is, update parent data and g data
                # and if the node was in the closed_list, move it to open_list
                else:
                    if g[m] > g[n] + (aresta.distancia/aresta.condicao):
                        g[m] = g[n] + (aresta.distancia/aresta.condicao)
                        parents[m] = n

                        if m in closed_list:
                            closed_list.remove(m)
                            open_list.add(m)

            # remove n from the open_list, and add it to closed_list
            # because all of his neighbors were inspected
            open_list.remove(n)
            closed_list.add(n)

        print('Path does not exist!')
        return None

    ################################################################################
    # Procura DFS
    ####################################################################################

    def procura_DFS(self, start, end, path=[], visited=set()):
        path.append(start)
        visited.add(start)

        if start.nome == end.nome:
            # calcular o custo do caminho funçao calcula custo.
            custoT = self.calcula_custo(path)
            return (len(path), custoT)
        for (adjacente, peso) in self.m_grafo[start]:
            if adjacente not in visited:
                resultado = self.procura_DFS(adjacente, end, path, visited)
                if resultado is not None:
                    return resultado
        path.pop()  # se nao encontra remover o que está no caminho......
        return None

    #####################################################
    # Procura BFS
    ######################################################

    def procura_BFS(self, start, end):
        # definir nodos visitados para evitar ciclos
        visited = set()
        fila = Queue()

        # adicionar o nodo inicial à fila e aos visitados
        fila.put(start)
        visited.add(start)

        # garantir que o start node nao tem pais...
        parent = dict()
        parent[start.nome] = None

        path_found = False
        while not fila.empty() and path_found == False:
            nodo_atual = fila.get()
            if nodo_atual.nome == end.nome:
                path_found = True
            else:
                for (adjacente, peso) in self.m_grafo[nodo_atual]:
                    if adjacente not in visited:
                        fila.put(adjacente)
                        parent[adjacente.nome] = nodo_atual
                        visited.add(adjacente)

        # Reconstruir o caminho
        path = []
        if path_found:
            path.append(end)
            while parent[end.nome] is not None:
                path.append(parent[end.nome])
                end = parent[end.nome]
            path.reverse()
            path.append(start)
            
            #print nome path
            for i in path:
                print(i.nome)
            # funçao calcula custo caminho
            custo = self.calcula_custo(path)
        return (len(path), custo)