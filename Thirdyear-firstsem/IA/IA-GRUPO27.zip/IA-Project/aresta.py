class Aresta:
    def __init__(self, distancia, condicao = 0):
        self.distancia = distancia
        self.condicao = condicao
    def __str__(self):
        return f"{self.distancia}, {self.condicao}"