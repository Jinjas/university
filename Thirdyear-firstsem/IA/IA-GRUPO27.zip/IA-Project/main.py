import sys
from encomenda import Encomenda
from meioTransporte import MeioTransporte
from estafeta import Estafeta
from cliente import Cliente
from rua import Rua
from graph import Grafo
from mapa import gerarGrafo, gerarRuas, gestor_de_eventos, obter_matriz, imprimir_matriz, parser
import random
from algoritmos import calcula_melhor_conjunto_de_rotas
from algoritmos import Heuristica
import sys

sys.setrecursionlimit(5000000)

def main():
    
    # ! Initial state's streets from rua_a to rua_zz
    n = 100
    ruas = gerarRuas(n) 

    # draw graph
    grafo = gerarGrafo(ruas, n)
    matriz = obter_matriz(grafo)
    armazem = grafo.get_nodo_by_name("Armazem")
    gestor_de_eventos(grafo, matriz, armazem.x, armazem.y, sys.argv[1])
    
    #print(matriz)

    #função que recebe 2 nodos e um valor e altera a condicao
    
              
      #devolve o melhor conjunto de rotas
      #A* é chamado entre cada encomenda da melhor rota Armazem->encomenda1->encomenda2....
    #melhor_rota = seleciona_conjunto_de_rotas(encomendas, [1,1,1], matriz, 0 ,0)

    #dados = parser()
    #realizaTarefasPorInstantes(grafo, matriz, 0, 0, dados)

  #   imprimir_matriz(matriz)
  #   grafo.draw()


main()