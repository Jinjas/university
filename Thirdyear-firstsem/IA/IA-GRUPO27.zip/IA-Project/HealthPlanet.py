class HealthPlanet:
    def __init__(self):
        self.clientes = {}
        self.encomendas = {} 
    
    def addclient(self, cliente):
        self.clientes[cliente.username] = cliente

    def verificarcliente(self, username, password):
        if username in self.clientes:
            cliente = self.clientes[username]
            if cliente.password == password:
                return True
        return False